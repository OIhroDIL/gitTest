# Extension Tests

This directory contains files to aid manual testing of the extension. To perform the tests, you will need to either have the extension installed or run the extension project, and open the `test` folder. You can then ensure the extension functionality as below:

1. The decoration status of files under `path-tests` folder match with the file names.
1. The decoration status of text in `tests.md` file match with the text descriptions.
